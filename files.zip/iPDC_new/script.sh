#!/usr/bin/env bash
make clean
make uninstall
make
make install
